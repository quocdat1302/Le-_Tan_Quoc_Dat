#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	//Viet chuong trinh nhap vao 2 so x, y va 1 trong 4 toan tu +, -, *, /
	//Neu la + thi in ra ket qua x + y
	//Neu la - thi in ra ket qua x - y
	//Neu la * thi in ra ket qua x * y
	//Neu la / thi in ra ket qua x / y (neu y = 0 thi thong bao khong chia duoc)
	int x, y;
    char toanTu;

    printf("Nhap x, y: ");
    scanf("%d %d", &x, &y);

    fflush(stdin);

    printf("Nhap vao toan tu: ");
    scanf(" %c", &toanTu);

    switch (toanTu) {
        case '+':
            printf("x + y = %d\n", x + y);
            break;
        case '-':
            printf("x - y = %d\n", x - y);
            break;
        case '*':
            printf("x * y = %d\n", x * y);
            break;
        case '/':
            if (y == 0) {
                printf("Khong chia duoc 0\n");
            } else {
                printf("x / y = %d\n", x / y);
            }
            break;
        default:
            printf("Toan tu khong hop le\n");
            break;
    }

	return 0;
}
