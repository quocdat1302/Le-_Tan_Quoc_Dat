#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//viet chuong trinh nhap vao so nguyen duong, in ra so chan hay so le
	int n;
	printf("nhap n: ");
	scanf("%d", &n);
	
	if(n % 2 == 0){
		printf("n la so chan");
	} else{
		printf("n la so le");
	}

	return 0;
}
