#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//Viet chuong trinh nhap so gio lam va luong/gio roi tinh so tien luong tong cong. 
	//Neu so gio lam lon hon 40 thi nhung gio lam doi ra duoc tinh 1,5 lan.
	
	float soGioLam, luongGio, luong;

    printf("Nhap so gio lam: ");
    scanf("%f", &soGioLam);

    printf("Nhap luong/gio: ");
    scanf("%f", &luongGio);
    
    if (soGioLam > 40) {
    	luong = 40 * luongGio + (soGioLam - 40) * 1.5 * luongGio;
    } else {
    	luong = soGioLam * luongGio;
    }
    printf("Tong luong la: %.2f\n", luong);

	return 0;
}
