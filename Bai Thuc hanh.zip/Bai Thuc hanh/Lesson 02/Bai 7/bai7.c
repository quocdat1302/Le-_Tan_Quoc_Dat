#include <stdlib.h>

int main() {
  int nguoi, may;
  char tiep_tuc = 'y';

  while (tiep_tuc == 'y') {

    printf("Chon: (1: keo, 2: bua, 3: bao)\n");
    scanf("%d", &nguoi);

    may = 3;

    switch (nguoi) {
      case 1:
        printf("May thang!\n");
        break;
      case 2:
        printf("May thang!\n");
        break;
      case 3:
        printf("Nguoi choi thang!\n");
        break;
    }

    printf("Tiep tuc (y/n)?\n");
    scanf(" %c", &tiep_tuc);
  }

  return 0;
}
