#include <stdio.h>
#include <stdlib.h>
#include <math.h> 

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float a, b, c, p, s;
	
	printf("Nhap vao 3 canh cua tam giac: \n");
	printf("Canh a: ");
	scanf("%f", &a);
	printf("Canh b: ");
	scanf("%f", &b);
	printf("canh c: ");
	scanf("%f", &c);
	
	p = (a + b + c) / 2;
	s = sqrt(p * (p - a) * (p - b) * (p - c));
	
	printf("Chu vi = %5.2f, va dien tich = %5.2f\n", 2 * p, s); 
	
	return 0;
}
