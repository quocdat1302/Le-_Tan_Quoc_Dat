#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a, b;
	
	printf("nhap so nguyen thu nhat:  ");
	scanf("%d", &a);
	
	printf("nhap so nguyen thu hai: ");
	scanf("%d", &b);
	
	printf("****************************\n");
	 
	int sum = a + b;
	int hieu = a - b;
	int tich = a * b;
	int thuong = a / b;
	
	printf("%d + %d = %d \n", a, b, sum);
	printf("%d - %d = %d \n", a, b, hieu); 
	printf("%d * %d = %d \n", a, b, tich);
	printf("%d / %d = %d \n", a, b, thuong);
	

	return 0;
}
