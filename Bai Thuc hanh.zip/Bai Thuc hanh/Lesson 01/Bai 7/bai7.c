#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	// khai bao bien
	float Chieu_dai, Chieu_rong, Chu_vi, Dien_tich;
	
	//nhap du lieu tu ban phim
	printf("Nhap chieu dai cua hinh chu nhat: ");
	scanf("%f", &Chieu_dai);
	printf("Nhap chieu rong cua hinh chu nhat: ");
	scanf("%f", &Chieu_rong);
	
	//tinh toan chu vi va dien tich
	Chu_vi = 2 * (Chieu_dai + Chieu_rong);
	Dien_tich = Chieu_dai * Chieu_rong; 
	
	// in ket qua
	printf("Chu vi cua hinh chu nhat la: %5.2f\n", Chu_vi);
	printf("Dien tich cua hinh chu nhat la: %5.2f\n", Dien_tich); 
	  
	return 0;
}
