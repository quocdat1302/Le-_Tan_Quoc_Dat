#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float bankinh, chuvi, hinhtron;
	printf("nhap ban kinh cua hinh tron: ");
	scanf("%f", &bankinh);
	hinhtron = 2 * 3.14 * bankinh;
	chuvi = 3.14 * bankinh * bankinh;
	printf("chu vi cua hinh tron la: %.2f\n", hinhtron);
	printf("dien tich cua hinh tron la: %.2f\n", chuvi); 

	return 0;
}
