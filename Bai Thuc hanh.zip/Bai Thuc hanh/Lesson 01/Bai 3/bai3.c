#include <stdio.h>
#include <math.h>

int main() {

  int x;
  float sinx, cosx;
  
  printf("Nhap so do: ");
  scanf("%d", &x);

  sinx = sin(x * 3.1416 / 180);
  cosx = cos(x * 3.1416 / 180);

  printf("Sin(%d) = %5.2f, Cos(%d) = %5.2f\n", x, sinx, x, cosx);

  return 0;
}

