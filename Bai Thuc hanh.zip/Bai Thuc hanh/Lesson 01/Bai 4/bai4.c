#include <stdio.h>
#include <stdlib.h>
#include <math.h> 

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float x, c;
	
	printf("Nhap so x: ");
	scanf("%f", &x);
	c = sqrt(x);
	printf("Can bac hai cua %.2f = %.2f \n", x, c);
	 
	return 0;
}
