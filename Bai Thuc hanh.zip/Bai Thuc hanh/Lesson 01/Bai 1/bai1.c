#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
    // In cau a
    printf("Chao cac ban\n");

    // In cau b 
    printf("Chao\t\tcac\t\tban\n");

    // In cau c 
    printf("Chao\n\cac\n\nban\n");

	return 0;
}
