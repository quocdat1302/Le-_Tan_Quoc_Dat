#include <stdio.h>
#include <stdlib.h>
#include <math.h> 

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float x, c;
	int k;
	printf("Nhap x: ");
	scanf("%f", &x);
	printf("Nhap k: ");
	scanf("%d", &k);
	c = exp(log(x) / k);
	printf("Can bac %d cua %5.2f = %5.2f \n", k, x);
	return 0;
}
