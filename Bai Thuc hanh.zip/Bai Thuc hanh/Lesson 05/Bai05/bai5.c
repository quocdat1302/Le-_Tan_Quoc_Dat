#include <stdio.h>

void nhap_ma_tran(int mat[][100], int n, int m) {
    printf("Nhap ma tran:\n");
    int i, j; 
    for ( i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            printf("Nhap phan tu so [%d][%d]: ", i, j);
            scanf("%d", &mat[i][j]);
        }
    }
}

void xuat_ma_tran(const int mat[][100], int n, int m) {
    printf("Ma tran:\n");
    int i, j; 
	for ( i = 0; i < n; i++) {
        for ( j = 0; j < m; j++) {
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }
}

void tong_hai_ma_tran(const int mat1[][100], const int mat2[][100], int sum_mat[][100], int n, int m) {
    int i, j; 
	for ( i = 0; i < n; i++) {
        for ( j = 0; j < m; j++) {
            sum_mat[i][j] = mat1[i][j] + mat2[i][j];
        }
    }
}

void tich_hai_ma_tran(const int mat1[][100], int n1, int k, const int mat2[][100], int k2, int m, int product_mat[][100]) {
    int i, j, x; 
	for (i = 0; i < n1; i++) {
        for ( j = 0; j < m; j++) {
            product_mat[i][j] = 0;
            for ( x = 0; x < k; x++) {
                product_mat[i][j] += mat1[i][x] * mat2[x][j];
            }
        }
    }
}

int main() {
    int n, m;
    printf("Nhap so ham cua ma tran: ");
    scanf("%d", &n);
    printf("Nhap so cot cua ma tran: ");
    scanf("%d", &m);

    int mat1[100][100];
    int mat2[100][100];
    int sum_mat[100][100];
    int product_mat[100][100];

    printf("Nhap ma tran thu nhat:\n");
    nhap_ma_tran(mat1, n, m);
    printf("Nhap ma tran thu hai:\n");
    nhap_ma_tran(mat2, n, m);

    printf("Ma tr?n t?ng hai ma tr?n:\n");
    tong_hai_ma_tran(mat1, mat2, sum_mat, n, m);
    xuat_ma_tran(sum_mat, n, m);

    int k;
    printf("Nhap so cot cua ma tran thu hai: ");
    scanf("%d", &k);

    printf("Nhap ma tran thu nhat:\n");
    nhap_ma_tran(mat1, n, k);
    printf("Nhap ma tran thu hai:\n");
    nhap_ma_tran(mat2, k, m);

    printf("Ma tran tich hai ma tran:\n");
    tich_hai_ma_tran(mat1, n, k, mat2, k, m, product_mat);
    xuat_ma_tran(product_mat, n, m);

    return 0;
}
