#include <stdio.h>

void nhap_mang(int arr[], int n) {
	int i; 
    for (i = 0; i < n; i++) {
        printf("Nhap phan tu %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
}

void tong_hai_mang(const int arr1[], const int arr2[], int sum_arr[], int n) {
    int i; 
	for (i = 0; i < n; i++) {
        sum_arr[i] = arr1[i] + arr2[i];
    }
}

void giao_hai_tap_hop(const int arr1[], int n1, const int arr2[], int n2, int intersection[], int* intersection_size) {
    *intersection_size = 0;
    int i, j; 
	for (i = 0; i < n1; i++) { 
		for (j = 0; j < n2; j++) {
            if (arr1[i] == arr2[j]) {
                intersection[*intersection_size] = arr1[i];
                (*intersection_size)++;
                break;
            }
        }
    }
}

void hop_hai_tap_hop(const int arr1[], int n1, const int arr2[], int n2, int union_arr[], int* union_size) {
    *union_size = 0;
    int i, j; 
	for ( i = 0; i < n1; i++) {
        union_arr[*union_size] = arr1[i];
        (*union_size)++;
    }
    for (i = 0; i < n2; i++) {
        int is_duplicate = 0;
        for ( j = 0; j < *union_size; j++) {
            if (arr2[i] == union_arr[j]) {
                is_duplicate = 1;
                break;
            }
        }
        if (!is_duplicate) {
            union_arr[*union_size] = arr2[i];
            (*union_size)++;
        }
    }
}

void main() {
    int n;
    printf("Nhap so phan tu cua mang: ");
    scanf("%d", &n);

    int arr1[n];
    printf("Nhap mang thu nhat:\n");
    nhap_mang(arr1, n);

    int arr2[n];
    printf("Nhap mang thu hai:\n");
    nhap_mang(arr2, n);

    int sum_arr[n];
    printf("Mang tong hai mang:\n");
    tong_hai_mang(arr1, arr2, sum_arr, n);
    int i; 
	for ( i = 0; i < n; i++) {
        printf("%d ", sum_arr[i]);
    }
    printf("\n");

    int intersection[n];
    int intersection_size;
    printf("Giao cua hai tap hop:\n");
    giao_hai_tap_hop(arr1, n, arr2, n, intersection, &intersection_size); 
	for (i = 0; i < intersection_size; i++) {
        printf("%d ", intersection[i]);
    }
    printf("\n");

    int union_arr[n * 2];
    int union_size;
    printf("hop cua hai tap hop:\n");
    hop_hai_tap_hop(arr1, n, arr2, n, union_arr, &union_size);
	for (i = 0; i < union_size; i++) {
        printf("%d ", union_arr[i]);
    }
    printf("\n");
}
